// Dev simulation logic
