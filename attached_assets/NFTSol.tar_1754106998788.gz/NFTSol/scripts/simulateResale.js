// Simulated resale logic
