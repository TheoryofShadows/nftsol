import{j as t}from"./index-Iajopkj_.js";function g({score:e,verified:o,summary:l,size:a="md",showPulse:i=!1}){const r=o!==void 0?o:e>70,s=!r&&e>=50,d=()=>r?"bg-gradient-to-r from-green-500/20 to-emerald-500/20 border-green-400/50 text-green-300":s?"bg-gradient-to-r from-yellow-500/20 to-amber-500/20 border-yellow-400/50 text-yellow-300":"bg-gradient-to-r from-red-500/20 to-orange-500/20 border-red-400/50 text-red-300",x=()=>r?"✅":"⚠️",n=()=>r?"Verified":s?"Moderate":"Low Trust",u={sm:"px-2 py-1 text-xs",md:"px-3 py-1.5 text-sm",lg:"px-4 py-2 text-base"};return t.jsxs("div",{className:`
        inline-flex items-center gap-1.5 rounded-full border-2 font-semibold transition-all duration-300
        ${d()}
        ${u[a]}
        ${i?"animate-pulse":""}
        hover:scale-105 cursor-help
      `,title:l?`${n()}: ${e}% - ${l}`:`${n()}: ${e}%`,children:[t.jsx("span",{className:"text-base",children:x()}),t.jsx("span",{children:n()}),t.jsxs("span",{className:"opacity-75",children:["(",e,"%)"]})]})}export{g as T};
